const symbols = [

  // نوشیدنی
  { id: "water", title: "آب", category: "نوشیدنی", emoji: "💧" },
  { id: "milk", title: "شیر", category: "نوشیدنی", emoji: "🥛" },
  { id: "tea", title: "چای", category: "نوشیدنی", emoji: "🍵" },
  { id: "juice", title: "آبمیوه", category: "نوشیدنی", emoji: "🧃" },
  { id: "yogurt_drink", title: "دوغ", category: "نوشیدنی", emoji: "🥛" },

  // غذا
  { id: "food", title: "غذا", category: "غذا", emoji: "🍲" },
  { id: "bread", title: "نان", category: "غذا", emoji: "🍞" },
  { id: "rice", title: "برنج", category: "غذا", emoji: "🍚" },
  { id: "apple", title: "سیب", category: "غذا", emoji: "🍎" },
  { id: "qabuli", title: "قابلی", category: "غذا", emoji: "🍛" },
  { id: "bolani", title: "بولانی", category: "غذا", emoji: "🥟" },
  { id: "egg", title: "تخم‌مرغ", category: "غذا", emoji: "🥚" },
  { id: "meat", title: "گوشت", category: "غذا", emoji: "🥩" },
  { id: "soup", title: "آش", category: "غذا", emoji: "🍜" },

  // افراد
  { id: "mother", title: "مادر", category: "افراد", emoji: "👩" },
  { id: "father", title: "پدر", category: "افراد", emoji: "👨" },
  { id: "brother", title: "برادر", category: "افراد", emoji: "👦" },
  { id: "sister", title: "خواهر", category: "افراد", emoji: "👧" },
  { id: "teacher", title: "معلم", category: "افراد", emoji: "👩‍🏫" },
  { id: "friend", title: "دوست", category: "افراد", emoji: "🧑‍🤝‍🧑" },
  { id: "grandmother", title: "مادربزرگ", category: "افراد", emoji: "👵" },
  { id: "grandfather", title: "پدربزرگ", category: "افراد", emoji: "👴" },

  // نیازها
  { id: "toilet", title: "تشناب", category: "نیازها", emoji: "🚻" },
  { id: "sleep", title: "خواب", category: "نیازها", emoji: "😴" },
  { id: "help", title: "کمک", category: "نیازها", emoji: "🆘" },
  { id: "yes", title: "بلی", category: "نیازها", emoji: "✅" },
  { id: "no", title: "نخیر", category: "نیازها", emoji: "❌" },
  { id: "want", title: "می‌خواهم", category: "نیازها", emoji: "🙏" },
  { id: "more", title: "بیشتر", category: "نیازها", emoji: "➕" },
  { id: "stop", title: "بس است", category: "نیازها", emoji: "🛑" },
  { id: "thirsty", title: "تشنه", category: "نیازها", emoji: "🥵" },
  { id: "hungry", title: "گرسنه", category: "نیازها", emoji: "😋" },

  // احساسات
  { id: "happy", title: "خوشحال", category: "احساسات", emoji: "😊" },
  { id: "sad", title: "غمگین", category: "احساسات", emoji: "😢" },
  { id: "angry", title: "عصبانی", category: "احساسات", emoji: "😡" },
  { id: "afraid", title: "ترسیده", category: "احساسات", emoji: "😨" },
  { id: "tired", title: "خسته", category: "احساسات", emoji: "😩" },
  { id: "love", title: "دوست دارم", category: "احساسات", emoji: "❤️" },
  { id: "bored", title: "حوصله‌ام سر رفته", category: "احساسات", emoji: "😑" },

  // سلامت
  { id: "pain", title: "درد", category: "سلامت", emoji: "🤕" },
  { id: "doctor", title: "دکتر", category: "سلامت", emoji: "👨‍⚕️" },
  { id: "medicine", title: "دوا", category: "سلامت", emoji: "💊" },
  { id: "hospital", title: "شفاخانه", category: "سلامت", emoji: "🏥" },
  { id: "fever", title: "تب", category: "سلامت", emoji: "🤒" },
  { id: "hurt", title: "زخم", category: "سلامت", emoji: "🩹" },

  // مکان‌ها
  { id: "home", title: "خانه", category: "مکان‌ها", emoji: "🏠" },
  { id: "school", title: "مکتب", category: "مکان‌ها", emoji: "🏫" },
  { id: "park", title: "پارک", category: "مکان‌ها", emoji: "🌳" },
  { id: "mosque", title: "مسجد", category: "مکان‌ها", emoji: "🕌" },
  { id: "market", title: "بازار", category: "مکان‌ها", emoji: "🛒" },
  { id: "clinic", title: "کلینیک", category: "مکان‌ها", emoji: "🏥" }

];


let sentence = [];
let currentCategory = "همه";


function loadList(key) {
  try {
    return JSON.parse(localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
}


function saveList(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}


let favorites = loadList("neginFavorites");
let recent = loadList("neginRecent");


/* =========================
   RENDER
========================= */

function renderSymbols(list = symbols) {
  const grid = document.getElementById("aacGrid");
  grid.innerHTML = "";

  if (list.length === 0) {
    grid.innerHTML = '<div class="empty">کلمه‌ای پیدا نشد.</div>';
    return;
  }

  list.forEach(symbol => {
    const isFavorite = favorites.some(item => item.id === symbol.id);

    const button = document.createElement("button");
    button.className = "symbol" + (isFavorite ? " is-favorite" : "");
    button.type = "button";
    button.setAttribute("aria-label", symbol.title + (isFavorite ? " (علاقه‌مندی)" : ""));

    button.innerHTML = `
      <span class="symbol-emoji" aria-hidden="true">${symbol.emoji}</span>
      <span class="symbol-title">${symbol.title}</span>
      ${isFavorite ? '<span class="fav-badge" aria-hidden="true">⭐</span>' : ''}
    `;

    button.onclick = () => {
      addWord(symbol);
    };

    // دوبار لمس برای علاقه‌مندی (موبایل و دسکتاپ)
    let lastTap = 0;
    button.addEventListener("click", (e) => {
      const now = Date.now();
      if (now - lastTap < 350) {
        e.preventDefault();
        toggleFavorite(symbol);
        renderSymbols(
          currentCategory === "همه" && !document.getElementById("searchInput").value
            ? symbols
            : getFilteredList()
        );
      }
      lastTap = now;
    });

    grid.appendChild(button);
  });
}


function getFilteredList() {
  const input = document.getElementById("searchInput");
  const query = input.value.trim().toLowerCase();
  let list = symbols;

  if (currentCategory !== "همه") {
    list = list.filter(symbol => symbol.category === currentCategory);
  }

  if (query) {
    list = list.filter(symbol =>
      symbol.title.toLowerCase().includes(query)
    );
  }

  return list;
}


/* =========================
   ADD WORD
========================= */

function addWord(symbol) {
  sentence.push(symbol.title);
  updateSentence();
  speak(symbol.title);
  addRecent(symbol);
}


/* =========================
   UPDATE SENTENCE
========================= */

function updateSentence() {
  const element = document.getElementById("sentence");

  if (sentence.length === 0) {
    element.textContent = "جمله خود را بسازید";
    return;
  }

  element.textContent = sentence.join(" ");
}


/* =========================
   TEXT TO SPEECH
========================= */

function speak(text) {
  if (!("speechSynthesis" in window)) {
    alert("دستگاه شما از پخش صدا پشتیبانی نمی‌کند.");
    return;
  }

  speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "fa-IR";
  utterance.rate = 0.78;
  utterance.pitch = 1.05;
  utterance.volume = 1;

  // تلاش برای انتخاب صدای بهتر فارسی اگر موجود باشد
  const voices = speechSynthesis.getVoices();
  const preferred = voices.find(v =>
    v.lang.startsWith("fa") || v.lang.startsWith("ar")
  );
  if (preferred) {
    utterance.voice = preferred;
  }

  speechSynthesis.speak(utterance);
}


/* =========================
   SPEAK SENTENCE
========================= */

function speakSentence() {
  if (sentence.length === 0) return;
  speak(sentence.join(" "));
}


/* =========================
   CLEAR
========================= */

function clearSentence() {
  sentence = [];
  updateSentence();
}


/* =========================
   CATEGORY
========================= */

function filterCategory(category) {
  currentCategory = category;
  document.getElementById("searchInput").value = "";
  searchSymbols();
}


/* =========================
   SEARCH
========================= */

function searchSymbols() {
  renderSymbols(getFilteredList());
}


/* =========================
   FAVORITES
========================= */

function toggleFavorite(symbol) {
  const exists = favorites.some(item => item.id === symbol.id);

  if (exists) {
    favorites = favorites.filter(item => item.id !== symbol.id);
  } else {
    favorites.push(symbol);
  }

  saveList("neginFavorites", favorites);
}


/* =========================
   RECENT
========================= */

function addRecent(symbol) {
  recent = recent.filter(item => item.id !== symbol.id);
  recent.unshift(symbol);
  recent = recent.slice(0, 12);
  saveList("neginRecent", recent);
}


/* =========================
   SHOW FAVORITES
========================= */

function showFavorites() {
  if (favorites.length === 0) {
    alert("هنوز کلمه‌ای به علاقه‌مندی‌ها اضافه نشده است.\n\nبرای افزودن، روی یک کلمه دوبار لمس کنید.");
    return;
  }

  currentCategory = "همه";
  document.getElementById("searchInput").value = "";
  renderSymbols(favorites);
}


/* =========================
   SHOW RECENT
========================= */

function showRecent() {
  if (recent.length === 0) {
    alert("هنوز کلمه‌ای استفاده نشده است.");
    return;
  }

  currentCategory = "همه";
  document.getElementById("searchInput").value = "";
  renderSymbols(recent);
}


/* =========================
   EMERGENCY
========================= */

function showEmergency() {
  sentence = ["کمک", "لطفاً", "من به کمک نیاز دارم"];
  updateSentence();
  speak("کمک لطفاً من به کمک نیاز دارم");
}


/* =========================
   CONNECTION
========================= */

function updateConnection() {
  const element = document.getElementById("connectionStatus");

  if (navigator.onLine) {
    element.textContent = "🟢 آنلاین";
  } else {
    element.textContent = "🟠 حالت آفلاین";
  }
}


window.addEventListener("online", updateConnection);
window.addEventListener("offline", updateConnection);


/* =========================
   SERVICE WORKER
========================= */

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("sw.js")
      .catch(error => console.log("Service Worker:", error));
  });
}


/* =========================
   VOICES LOAD
========================= */

if ("speechSynthesis" in window) {
  speechSynthesis.onvoiceschanged = () => {
    // صداها بارگذاری شدند
  };
}


/* =========================
   START
========================= */

renderSymbols();
updateConnection();
